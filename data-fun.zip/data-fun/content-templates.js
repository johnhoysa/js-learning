export function renderTitle(model) {
  return `<h1><span>Next Saturday</span>${superData.squadName} vs ${villianData.squadName}</h1>`;
}
